/*
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

//Game class that has the parameters to initialize the game through startGame method

public class Game 
{
	
	//method that combines all the methods and variables to play the game
	public static void startGame() 
	{
		
		
				/*****Welcome Section of the Game and Hole Number Declaration*****/
		
		// initialize an instance of the player class and welcome prompt
		Player player = new Player(); 
		System.out.println("Welcome to TTY Golf!");
		
		//establish an array that will store string information used to identify hole number
		String [] holenum = GameInit.holenum;
		
		
				/*****Main Loop that initialize and plays the game*****/
		
		do 
		{
			
				/***Establish initial variables and starting conditions***/
			
			//initializes the variables for hole and done
			int hole;
			boolean done = false;
			
			//sets the player's shots and score to 0.
			player.setShots(0);
			player.setScore(0); 
			
							/***Course Selection Section***/
			
			/*calls on the chooseCourse method from GameMethod
			 which prompts user to input 1 or 2 to select a specific course
			 or 0 to quit and sets that value to coursenum. If, 0
			 then the do while loop breaks.
			 */
			
			int coursenum = GameMethods.chooseCourse();
			if(coursenum == -1)
			{
				break;	
			}
			
			//This initializes the player and course based on input
			player.setCourse(coursenum); 
			Course course = GameInit.courses[coursenum];
			
			//displays to the user what course the user is playing on
			System.out.println("\nYou are playing the " + course.getCourseName() + ".\n");
			
			
								/***Round Loop Section***/
			
			/*At the start of every round(hole), 
			 it will display: number of hole, distance to hole, and par number*/
			
			for( hole = 1; hole <= 18; hole++)
			{
				System.out.println("You are at the " + holenum[hole-1] + " tee. " + course.getHoleYards(hole) + " yards, par " + course.getHolePar(hole) + ".");
				
				//this double will be equal to hole distance for a certain hole based on iteration in for loop
				double distance = course.getHoleYards(hole);
				
								/**Hole Loop Section**/
				do
				{
					//asks for club and power then makes new distance
					 distance = GameMethods.newDist(distance);
					 
					//if user inputs 0 breaks out of the hole
					if(distance == -1)
					{
						done = true;
						break;
					}
					
					//increments the shot number if the user doesn't quit
					player.setShots(player.getShots() + 1);
					
					//Rounds  
					GameMethods.shotCheck(distance, player, course, hole);
					
				}while(!GameMethods.shotMade(distance));
				
								/***End of Hole Loop Section***/
				
				
				//if user quits, break from for loop else prints the score up to this round
				if(done)
				{
					break;
				}
				else
				{
					GameMethods.printHoleScore(player, hole,  holenum);
				}
		}	
			
							  /***End of Round Loop Section***/
			
			
		//prints the player round score after first hole and when score not 0
		if (player.getScore() != 0 && hole != 1)
		{
			GameMethods.printGameScore(player, hole);
		}
		
		
		}
		while(GameMethods.contPlaying());
		
							/***End of Main Loop Section***/
		
		
		//Print Goodbye Prompt
		System.out.println("Thanks for playing TTY Golf!");
	}
}
