/*
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

import java.util.Scanner;

//Class that contains all the methods to make the game functional
public class GameMethods extends GameInit 
{
	//Method that establishes what club and power is used 
	private static double takeShot(double distance)
	{
		//initialize scanner and club variables
		Scanner scan = new Scanner(System.in);
		int club;
		
		/*Conditional: If the ball is within 20 yards then utilize putter
		 else utilize the club based on user input*/
		
		if(distance<=20) 
		{
			System.out.println("You are on the green, so you will use the putter.");
			club = 10;
		}
		else 
		{
			//establish the Choice variable
			int clubChoice;
			
			//Loop that prompts for user input for club; has a fail safe if input is not 1-10
			do 
			{
				System.out.print("Choose your club [1,10] or enter 0 to quit: ");
				clubChoice = scan.nextInt();
				if(!(0<=clubChoice && clubChoice<=10)) 
				{
					System.out.println("This is not a valid club.");
				}
			}
			while(!(0<=clubChoice && clubChoice<=10));
			
			//Ends the game if the user inputs 0
			if(clubChoice == 0)
			{
				return -1;
			}
			
			//Selects the right club; subtracts 1 to account for index
			club = clubChoice-1;
		}
		
		//establish the power variable
		int power;
		
		//Loop that prompts for user input for Power; has a fail safe if input is not 1-10
		do 
		{
			System.out.print("Power [1,10] or enter 0 to quit: ");
			power = scan.nextInt();
			if(!(0<=power && power<=10)) 
			{
				System.out.println("This is not a valid power level, try again.");
			}
		}
		while(!(0<=power && power<=10));
		
		//Ends the game if the user inputs 0
		if(power == 0)
		{
			return -1;
		}
		else
		{
			return clubs[club].shot(power);
		}
	}
	
	
	//Method that calculates new distance after shot is made
	public static double newDist(double distance) 
	{
		
		//if user inputs 0 for club, or power, returns -1, quitting the round
		double shot = takeShot(distance);
		if(shot == -1)
		{
			return -1;
		}
		else
		{
			return Math.abs(distance-shot); //absolute value accounts for shots past the hole
		}
	}
	
	
	//Method to check if distance is within 1 ft of the hole
	
	public static boolean shotMade(double distance) 
	{
		//checks if the distance is 1 ft or 1/3 of a yard from the hole
		if(distance<=(1.0/3.0)) 
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	
	//Method that prompts user input for Course selection 

	public static int chooseCourse() 
	{
		//Establish scanner and choice varaible
		Scanner scan = new Scanner(System.in);
		int choice;
		
		//Loop that asks for user input for course ; has a fail-safe if not one of the choices
		do 
		{
			System.out.print("Choose a course or quit by inputting 0.\n1 - Genesee Valley Park North\n2 - Old Course at St. Andrews.\nYour choice [0-2]: ");
			choice = scan.nextInt();
			if(!(1==choice || choice==2 || choice == 0)) 
			{
				System.out.println("This is not a valid choice level, try again.");
			}
		}
		while(!(1==choice || choice==2 || choice == 0));
		
		return choice-1; //accounts for the index position using the -1
	}
	
	
	//Method calculates the score 

	public static int currentScore(int shots, int hole, int course) 
	{
		
		int totalpar=0; //initializes the total par to 0 
		
		//takes the sum of all the par numbers for the entire course
		for(int i=1;i<=hole;i++) 
		{
			totalpar+=courses[course].getHolePar(i);
		}
		
		return totalpar-shots; //returns the score from this difference
	}
	
	
	//Method that prints distance from the hole in yards

	public static void printYards(double y) 
	{
		System.out.printf("You are %.2f yards from the hole.\n\n", y); //prints distance up to 2 decimal places
	}
	
	
	//Method that asks the user if they want to continue playing

	public static boolean contPlaying() 
	{
		//Initializes the variables and scanner
		boolean choice;
		Scanner scan = new Scanner(System.in);
		
		//prompt user if they want to continue to play
		System.out.print("Would you like to continue playing? (y/n): ");
		String input="";
		
		//loop that checks if player wants to continue or to quit
		do {
			input = scan.next();
			if(!(input.equals("y") || input.equals("n"))) 
			{
				System.out.println("Invalid input, try again."); //appears if user does not input : "y" or "n"
			}
		}
		while(!(input.equals("y") || input.equals("n")));
		
		//Conditional: if "y" allows user to continue else it quits
		if(input.equals("y")) 
		{
			choice = true;
		} 
		else 
		{
			choice = false;
		}
		
		return choice; 
	}
	
	
	//Method that names unique shots depending on when it reaches the hole
	public static String scoreName(int par, int shot) 
	{
		String out = "";
		
		//if the ball reaches the hole in one shot, print "Hole in one!"
		if(shot==1) {
			out = "Hole in one!";
		}
		else
		{
			int diff = shot-par;
			
			if(diff>=1)
			{
				out = ("Bogey +" + diff);
			}
			
			else
			{
				//prints cases based on the difference between shot and par
				switch(diff) 
				{
					case -1: out = "Birdie!"; break;
					case -2: out = "Eagle!"; break;
					case -3: out = "Albatross!"; break;
				}
			}
		}
		return out;
	}
	
	
	//Method that prints the score based on par number
	
	public static void printHoleScore(Player player, int hole,String[] holenum)
	{
		//obtains the score through currentScore method after a shot is made
		int score = GameMethods.currentScore(player.getScore(), hole, player.getCourse());
		
		//provides three  conditions for printing score: it is score + under par, over-par, or par"
		if(score > 0) 
		{
		System.out.println("Your score after the " + holenum[hole-1] + " hole is: " + score + " under par.");
		}
		
		else if(score < 0)
		{
			System.out.println("Your score after the " + holenum[hole-1] + " hole is: " + Math.abs(score) + " over par.");
		}
		
		else
		{
			System.out.println("Your score after the " + holenum[hole-1] + " hole is:  par.");
		}
		System.out.println(); //returns a new line
	}
	
	
	//Method that prints the final score at the end of the game
	
	public static void printGameScore(Player player, int hole)
	{
		//obtains the score through currentScore method after completion of the game
		int totalpar = GameMethods.currentScore(player.getScore(), hole - 1, player.getCourse());
		
		//provides three  conditions for printing final score: it is score + under par, over-par, or par"
		if(totalpar > 0)
		{
			System.out.println("Your final score for this game is: " + (totalpar) + " under. Good job!");
		}
		else if(totalpar < 0)
		{
			System.out.println("Your final score for this game is: " + (Math.abs(totalpar)) + " over. Better luck next time...");
		}
		else
		{
			System.out.println("Your final score for this game is:  par. Good job!");
		}
		
		System.out.println(); //return a new line
	}
	

	
	//method that adds and displays the score after each hole, resets the shots to 0
	//Method that provides conditions to see if the shot makes into the hole
	public static void shotCheck (double y, Player player, Course course, int hole) 
	{
	
	//Method that adds up the player score up after the end of a hole, or prints distance traveled so far
	if(GameMethods.shotMade(y))
	{
		System.out.println(GameMethods.scoreName(course.getHolePar(hole), player.getShots())); //prints out the score name
		player.setScore(player.getScore() + player.getShots()); //total player score up to end of this hole
		player.setShots(0); //resets the shot number to 0
	}
	
	else
	{
		GameMethods.printYards(y); //prints the distance it traveled so far in yards
	}
	
	}
}