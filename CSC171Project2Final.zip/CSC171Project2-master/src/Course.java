/*
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

//Main Class for Course Information

public class Course 
{
	
	
	/*****Field Variables for Constructor for Course*****/
	//Creates 2-D array for holes: 18 holes, 2 bits of info: distance to hole and par number
	private int[][] holedata = new int[18][2]; 
	private String courseName; 

	
	/*****Constructor for Course*****/
	public Course(String name, int[][] holedata) 
	{
		this.courseName=name;
		this.holedata=holedata;
	}

	
	/*****Establish Getters for Course Class*****/
	
	//getter that returns the courseName
	public String getCourseName() 
	{
		return courseName;
	}

	
	//returns the start distance to the hole for all 18 holes
	public int getHoleYards(int hole) 
	{
		return holedata[hole-1][0]; 
	}
	
	
	//returns the par number to the hole for all 18 holes
	public int getHolePar(int hole) {
		return holedata[hole-1][1];
	}
	
	
	/*This getter is used to display par number for each hole by calling each index 
	  through every iteration in the loop up to 18 for each hole and add that to the 
	  variable par.
	 */
	public int getCoursePar() 
	{
		int par = 0;
		
		for(int i=0;i<18;i++) 
		{
			par+=holedata[i][1];
		}
		return par;
	}
	
	


}
