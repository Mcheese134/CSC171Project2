
/*
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

import java.util.Random;

//Putter class that is enabled when the ball is 20 yards from hole or in the green; inherits from Club

public class Putter extends Club
{
	//establish a random variable for use in shot method
	Random rand = new Random(); 
	
	
	/*****Establish Constructor for Club*****/
	
	//constructor for Putter and calls Super-Constructor from Club
	public Putter(int mean, int stddev) 
	
	{
		super(mean, stddev);
	}

	
	/*****Array Data for Putter *****/
	
	//In feet, data for the Mean and Standard Deviation respectively of a putter in a 2D array
	private int[][] putterData = 
		{
			{1,1},
			{2,1},
			{4,2},
			{8,2},
			{12,3},
			{16,3},
			{20,4},
			{25,4},
			{30,5},
			{40,5},	
		};
	
	//Provides Override to shot method in Clubs for Putter
	@Override
	public double shot(int p) 
	{
		double feet = rand.nextGaussian()*putterData[p-1][1]+putterData[p-1][0]; //calculates distance of shot in feet
		double yards = feet/3.0; //convert the distance of the shot into yards
		return yards; 
	}
}
