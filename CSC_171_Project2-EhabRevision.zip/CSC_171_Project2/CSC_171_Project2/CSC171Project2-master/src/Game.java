
public class Game {
	
	public static void startGame() {
		
		Player player = new Player();
		System.out.println("Welcome to TTY Golf!");
		
		do {
			int coursenum = GameMethods.chooseCourse();
			player.setCourse(coursenum);
			Course course = GameInit.courses[coursenum];
			System.out.println("\nYou are playing the " + course.getCourseName() + ".\n");
			for(int i = 1; i <= 18; i++)
			{
				System.out.println("You are at tee " + i +  ". " + course.getHoleYards(i) + " yards, par " + course.getHolePar(i) + ".");
				double y;
				do
				{
					y = course.getHoleYards(i);
					y = GameMethods.newDist(y);
					GameMethods.printYards(y);
					y = 0.2;
					if(GameMethods.shotMade(y))
					{
						System.out.println("\nYou made it in!");
					}
				}while(!GameMethods.shotMade(y));	
			}
			System.out.println("You won the course!");
		}while(GameMethods.contPlaying());

	}
}
