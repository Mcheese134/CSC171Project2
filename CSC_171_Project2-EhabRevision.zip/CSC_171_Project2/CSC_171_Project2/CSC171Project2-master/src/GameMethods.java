import java.util.Scanner;

public class GameMethods extends GameInit 
{
	
	private static double takeShot(double y)
	{
		Scanner scan = new Scanner(System.in);
		int club;
		if(y<=20) {
			System.out.println("You are on the green, so you will use the putter.");
			club = 10;
		}
		else {
			int clubChoice;
			do {
				System.out.print("Choose your club [1,10]: ");
				clubChoice = scan.nextInt();
				if(!(1<=clubChoice && clubChoice<=10)) {
					System.out.println("This is not a valid club.");
				}
			}while(!(1<=clubChoice && clubChoice<=10));
			club = clubChoice-1;
		}
			
		int power;
		do {
			System.out.print("Power [1,10]: ");
			power = scan.nextInt();
			if(!(1<=power && power<=10)) {
				System.out.println("This is not a valid power level, try again.");
			}
		}while(!(1<=power && power<=10));
		return clubs[club].shot(power);
	}
	
	public static double newDist(double y) {
		//absolute value guarantees distance will never be negative.
		return Math.abs(y-takeShot(y));
	}
	
	public static boolean shotMade(double y) {
		if(y<=(1.0/3.0)) {
			return true;
		}
		else {return false;}
	}

	public static int chooseCourse() {
		Scanner scan = new Scanner(System.in);
		int choice;
		do {
			System.out.print("Choose a course.\n1 - Genesee Valley Park North\n2 - Old Course at St. Andrews.\nYour choice [1-2]: ");
			choice = scan.nextInt();
			if(!(1==choice || choice==2)) {
				System.out.println("This is not a valid choice level, try again.");
			}
		}while(!(1==choice || choice==2));
		return choice-1;
	}

	public static int currentScore(int shots, int hole, int course) {
		int totalpar=0;
		for(int i=0;i<hole;i++) {
			totalpar+=courses[course].getHolePar(i);
		}
		return totalpar-shots;
	}

	public static void printYards(double y) {
		System.out.printf("You are %.2f yards from the hole.\n", y);
	}

	public static boolean contPlaying() {
		boolean choice;
		Scanner scan = new Scanner(System.in);
		System.out.print("Would you like to continue playing? (y/n): ");
		String input="";
		do {
			input = scan.next();
			if(!(input.equals("y") || input.equals("n"))) {
				System.out.println("Invalid input, try again.");
			}
		}while(!(input.equals("y") || input.equals("n")));
		if(input.equals("y")) {
			choice = true;
		} else {
			choice = false;
		}
		return choice;
	}
}
