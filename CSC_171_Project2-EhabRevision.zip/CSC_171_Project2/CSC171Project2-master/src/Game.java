

public class Game {
	
	public static void startGame() {
		
		Player player = new Player();
		System.out.println("Welcome to TTY Golf.");
		
		do {
			int coursenum = GameMethods.chooseCourse();
			player.setCourse(coursenum);
			Course course = GameInit.courses[coursenum];
			System.out.println("You are playing at " + course.getCourseName() + ".");
			for(int i = 1; i <= 18; i++)
			{
				System.out.println("You are at tee");
				double y;
				do
				{
					y = course.getHoleYards(i);
					y = GameMethods.newDist(y);
					GameMethods.printYards(y);
					y = 0.2;
					if(GameMethods.shotMade(y))
					{
						System.out.println("You made it in!");
					}
				}while(GameMethods.shotMade(y));	
				System.out.println("You have advanced onto hole " + i + " which is " + course.getHoleYards(i+1) + "yards away.");
			}
			System.out.println("You won the course!");
		}while(GameMethods.contPlaying());

	}
}
