import java.util.Random;

//create a class for the clubs in the golf game

public class Club 
{
	//initialize instance variable for constructor for Club
	private int mean;
	private int stddev;
	private Random rand = new Random();
	
	//initialize a constructor for Club
	public Club(int mean, int stddev) {
		this.mean = mean;
		this.stddev = stddev;
	}
	
	//initialize a method that controls shot power (or integer p : 1-10) of club 
	public double shot(int p) {
		
		
		//limit power between 1 and 10
		
		double g = rand.nextGaussian()*stddev + mean; 
		double mult = ((double) p)/(10.0); 
		return g*mult;
	}
}
