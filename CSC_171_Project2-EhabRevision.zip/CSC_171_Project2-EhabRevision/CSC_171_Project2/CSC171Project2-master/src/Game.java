
public class Game {
	
	public static void startGame() {
		
		Player player = new Player();
		System.out.println("Welcome to TTY Golf!");
		String [] holenum = {"first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "sevententh", "eighteenth"};
		do {
			int hole;
			boolean done = false;
			int shots = 0;
			player.setScore(0);
			
			int coursenum = GameMethods.chooseCourse();
			//if user inputs 0, quits entire game
			if(coursenum == -1){
				break;
			}
			player.setCourse(coursenum);
			Course course = GameInit.courses[coursenum];
			
			System.out.println("\nYou are playing the " + course.getCourseName() + ".\n");
			
			for( hole = 1; hole <= 18; hole++){
				
				System.out.println("You are at the " + holenum[hole-1] + " tee. " + course.getHoleYards(hole) + " yards, par " + course.getHolePar(hole) + ".");
				
				double y = course.getHoleYards(hole);
				
				do
				{
					
					 y = GameMethods.newDist(y);
					//if user inputs 0 for either club, or power quits entire game
					if(y == 0){
						done = true;
						break;
					}
					shots++;
					if(GameMethods.shotMade(y)){
						System.out.println(GameMethods.scoreName(course.getHolePar(hole), shots));
						player.setScore(player.getScore() + shots);
						shots = 0;
					}
					else{
						GameMethods.printYards(y);
					}
				}while(!GameMethods.shotMade(y));	
				//if user quits, break from for loop
				if(done){
					break;
				}
				else{
					GameMethods.printHoleScore(player, hole,  holenum);
			}
			//if user quits, break from game loop
			if(done){
				break;
			}
		}
		if (player.getScore() != 0 && hole != 1)
		{
			GameMethods.printRoundScore(player, hole);
		}
		/*else if(player.getScore() != 0)
		{
			System.out.println("Your final score was " + GameMethods.currentScore(player.getScore(), hole -1 , player.getCourse()));
		}*/
		}while(GameMethods.contPlaying());
		System.out.println("Thanks for playing TTY Golf!");
	}
}
