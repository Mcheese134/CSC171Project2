
public class Game {
	
	public static void startGame() {
		
		Player player = new Player();
		System.out.println("Welcome to TTY Golf!");
		String [] holenum = {"first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth", "tenth", "eleventh", "twelfth", "thirteenth", "fourteenth", "fifteenth", "sixteenth", "sevententh", "eighteenth"};
		do {
			boolean done = false;
			int coursenum = GameMethods.chooseCourse();
			//if user inputs 0, quits entire game
			if(coursenum == -1)
			{
				break;
			}
			player.setCourse(coursenum);
			Course course = GameInit.courses[coursenum];
			System.out.println("\nYou are playing the " + course.getCourseName() + ".\n");
			for(int i = 1; i <= 18; i++)
			{
				System.out.println("You are at the " + holenum[i-1] + " tee. " + course.getHoleYards(i) + " yards, par " + course.getHolePar(i) + ".");
				double y = course.getHoleYards(i);
				do
				{
					 y = GameMethods.newDist(y);
					//if user inputs 0 for either club, or power quits entire game
					if(y == 0)
					{
						done = true;
						break;
					}
					if(GameMethods.shotMade(y))
					{
						System.out.println("\nYou made it in!\n");
					}
					else
					{
						GameMethods.printYards(y);
					}
				}while(!GameMethods.shotMade(y) || done);	
				if(done)
				{
					break;
				}
			}
			if(done)
			{
				break;
			}
			else
			{
				System.out.println("You won the course!");
			}
		}while(GameMethods.contPlaying());
		System.out.println("Thanks for playing TTY Golf!");
	}
}
