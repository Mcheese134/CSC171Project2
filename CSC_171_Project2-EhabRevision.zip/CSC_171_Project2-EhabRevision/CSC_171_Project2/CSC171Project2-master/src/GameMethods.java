import java.util.Scanner;

public class GameMethods extends GameInit 
{
	
	private static double takeShot(double y)
	{
		Scanner scan = new Scanner(System.in);
		int club;
		if(y<=20) {
			System.out.println("You are on the green, so you will use the putter.");
			club = 10;
		}
		else {
			int clubChoice;
			do {
				System.out.print("Choose your club [1,10] or enter 0 to quit: ");
				clubChoice = scan.nextInt();
				if(!(0<=clubChoice && clubChoice<=10)) {
					System.out.println("This is not a valid club.");
				}
			}while(!(0<=clubChoice && clubChoice<=10));
			if(clubChoice == 0)
			{
				return clubChoice;
			}
			club = clubChoice-1;
		}
			
		int power;
		do {
			System.out.print("Power [1,10] or enter 0 to quit: ");
			power = scan.nextInt();
			if(!(0<=power && power<=10)) {
				System.out.println("This is not a valid power level, try again.");
			}
		}while(!(0<=power && power<=10));
		if(power == 0)
		{
			return power;
		}
		else
		{
			return clubs[club].shot(power);
		}
	}
	
	public static double newDist(double y) {
		//absolute value guarantees distance will never be negative.
		//if user inputs 0 for club, or power, returns 0
		double shot = takeShot(y);
		if(shot == 0)
		{
			return shot;
		}
		else
		{
			return Math.abs(y-shot);
		}
	}
	
	public static boolean shotMade(double y) {
		if(y<=(1.0/3.0)) {
			return true;
		}
		else {return false;}
	}

	public static int chooseCourse() {
		Scanner scan = new Scanner(System.in);
		int choice;
		do {
			System.out.print("Choose a course or quit by inputting 0.\n1 - Genesee Valley Park North\n2 - Old Course at St. Andrews.\nYour choice [0-2]: ");
			choice = scan.nextInt();
			if(!(1==choice || choice==2 || choice == 0)) {
				System.out.println("This is not a valid choice level, try again.");
			}
		}while(!(1==choice || choice==2 || choice == 0));
		return choice-1;
	}

	public static int currentScore(int shots, int hole, int course) {
		int totalpar=0;
		for(int i=0;i<hole;i++) {
			totalpar+=courses[course].getHolePar(i);
		}
		return totalpar-shots;
	}

	public static void printYards(double y) {
		System.out.printf("You are %.2f yards from the hole.\n\n", y);
	}

	public static boolean contPlaying() {
		boolean choice;
		Scanner scan = new Scanner(System.in);
		System.out.print("Would you like to continue playing? (y/n): ");
		String input="";
		do {
			input = scan.next();
			if(!(input.equals("y") || input.equals("n"))) {
				System.out.println("Invalid input, try again.");
			}
		}while(!(input.equals("y") || input.equals("n")));
		if(input.equals("y")) {
			choice = true;
		} else {
			choice = false;
		}
		return choice;
	}
}
