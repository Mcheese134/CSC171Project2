import java.util.Random;

public class Putter extends Club
{
	public Putter(int mean, int stddev) {
		super(mean, stddev);
	}

	Random rand = new Random();
	
	private int[][] data = {
			{1,1},
			{2,1},
			{4,2},
			{8,2},
			{12,3},
			{16,3},
			{20,4},
			{25,4},
			{30,5},
			{40,5},
			
	};
	
	@Override
	public double shot(int p) {
		double feet = rand.nextGaussian()*data[p-1][1]+data[p-1][0];
		double yards = feet/3.0;
		return yards;
	}
}
