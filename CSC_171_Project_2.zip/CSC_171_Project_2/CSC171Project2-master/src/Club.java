
/*
 
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

import java.util.Random;

//Main Class for Club Information

public class Club 
{
	
	//random variable used to randomize the power
		private Random rand = new Random();
	
		
	/*****Field Variables for Constructor for Club*****/
		
	//initialize instance variable for constructor for Club
		
			private int mean; //average distance that a certain club can make
			private int stddev; //standard deviation from the average for distance of a club
		
	
	/*****Establishes Constructor for Club*****/
	//initialize a constructor for Club
	public Club(int mean, int stddev) 
	{
		this.mean = mean;
		this.stddev = stddev;
	}
	
	
	/*****Method Section*****/
	
	//initialize a method that controls shot power of club 
	public double shot(int p) 
	{
		double gaussian = rand.nextGaussian()*stddev + mean; //gaussian distribution: normalizes the shot power 
		double multiplier = ((double) p)/(10.0); //multiplier : used to scale the intensity of the power
		return gaussian*multiplier; // value for power
	}
}
