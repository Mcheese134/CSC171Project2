/*
Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

//This main file is  used to start the game by calling the startGame() method
 
public class main 
{
	
	public static void main(String[] args) 
	{
		Game.startGame();
	}
}
