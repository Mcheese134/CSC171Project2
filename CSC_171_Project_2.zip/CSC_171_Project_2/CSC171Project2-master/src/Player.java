
/*
Group Members: Benjamin Keuhnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd

*/

//Main Class for Player Information

public class Player 
{
	
	/*****Field Variables for Constructor for Player*****/
	
	private int score;
	private int course;
	private int shots;

	/*****Getter and Setter Sections for Player*****/
	
	public int getCourse() 
	{
		return course;
	}

	public void setCourse(int course) 
	{
		this.course = course;
	}

	public int getScore() 
	{
		return score;
	}

	public void setScore(int score) 
	{
		this.score = score;
	}
	
	public int getShots()
	{
		return shots;
	}
	
	public void setShots(int shots)
	{
		this.shots = shots;
	}
			
}
