Group Members: Benjamin Kuehnert, Ehab Ajmal, and Nurfajri Rafiuddin
CSC171-Project 2 : TTY Golf  

NetIDs:
Benjamin Kuehnert - bkuehner
Ehab Ajmal - eajmal
Nurfajri Rafiuddin - nrafiudd


Medium: Eclipse-Oxygen for your operating system.
Library: Java SE 1.8  

1.Download the ZIP file 
2.Unzip the file. 
2.Open up Eclipse on your operating system.
3.Choose your preferential workspace directory 
4.Select any/all of the files under CSC171_Homework_Nurfajri_Rafiuddin/src/…
5.Run the code on the individual files on Eclipse


Class Information :

-Club.java : Main Class for information on Clubs

-Course.java : Main Class for information on Course

-Game.java : Main Class that initializes the game and runs it 

-GameInit.java : Main Class that stores data for Courses, Clubs, and Hole Number in 2-D arrays

-GameMethods.java : Main Class that contains all the methods utilized in Game.java to make the game functional.

-main.java : Runs the game

-Player.java : Main class for information on the Player

-Putter.java : Main class for information on Putter ; initialized when ball is within 20 yards of the 


Description:

This programs simulates a golf game. The game functions by first asking the user to choose between two courses: Genesee Valley Park North and Old Course at St. Andrews. The user also has the option to quit at the start. Each course has 18 hole or tees. If the user picks one of the courses, then the game proceeds to the first tee or hole of the course. Each tee has a distance to reach and a par number (or the number of strokes it should take to reach the hole). 

Afterwards, the user must select a club and power before they make a stroke. A stroke in golf is when the user makes an attempt the ball to reach the hole. In this game, the path of the ball when hit is linear towards the hole.


The goal of the game is to receive the lowest score possible at the end of the game. After the user gets the ball in the hole, the game will print the difference between the score and par number to find your score for that hole. This score will add up to your score from previous rounds and be printed out. This will repeat until the last hole is completed where it will display your final score.

Extra Credit:

Continue Playing Feature:

-The user can choose to continue playing a new game if they decide to from the round.

Quit Feature:
-The user can quit at any point in the game.

Shot Names:
-Depending on when the user makes the shot in, it will print out unique names like Bogey, Hole-in-One, Birdie, Eagle, and Albatross

Tee Indication:
-At the start of every hole, it will print what tee you are at.

E.G. : “You are at the third tee” <— it uses a string instead of an int for numbering the tee

Fail Safe System:
-If a user inputs an integer that does not correspond to any of the choices for club, power, or course then it will invalidate the user input and prompt for the choice again. 


